/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ageofempiresgui;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author vinurip
 */
public class ColorRenderer extends JLabel implements TableCellRenderer {

    public ColorRenderer() {
        setOpaque(true); //MUST do this for background to show up.
    }

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {

        if (column == 13) {
            try {
                if (Integer.valueOf(table.getValueAt(row, column).toString()) == 1) {
                    setBackground(empiresage.EmpiresConstants.colorPlayer1);

                } else if (Integer.valueOf(table.getValueAt(row, column).toString()) == 2) {
                    setBackground(empiresage.EmpiresConstants.colorPlayer2);

                } else {
                    setBackground(Color.WHITE);
                }
            } catch (NumberFormatException ex) {
                System.out.println(ex.getMessage());
                System.out.println("Error occured when painting the cell 13");
            }
        }
        if (column == 1 || column == 2 || column == 7 || column == 8) {
            try {
                if (Integer.valueOf(table.getValueAt(row, column).toString()) > empiresage.EmpiresConstants.fightersGoals) {
                    setBackground(Color.GREEN);
                } else {
                    setBackground(Color.RED);

                }
            } catch (NumberFormatException ex) {
                System.out.println("Error occured when painting the cells 1 /2/ 7/ 8");
            }
        }
        if (column == 4 || column == 10) {
            try {
                if (Integer.valueOf(table.getValueAt(row, column).toString()) > 
                        empiresage.EmpiresConstants.fightingUnitsGoals) {
                    setBackground(Color.GREEN);
                } else {
                    setBackground(Color.RED);

                }
            } catch (NumberFormatException ex) {
                System.out.println("Error occured when painting the cells 4 /10");
            }
        }
        setText(table.getValueAt(row, column).toString());
        return this;
    }

}
