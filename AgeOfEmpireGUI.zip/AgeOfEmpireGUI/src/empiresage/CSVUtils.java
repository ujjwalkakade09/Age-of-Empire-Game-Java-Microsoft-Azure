/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empiresage;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Asha
 */
public class CSVUtils {

    public void writeToFile(HashMap<String, HashMap> dataMap, String filename) throws FileNotFoundException, IOException {
        String path = "/Users/vinurip/NetBeansProjects/IMCSGroup4Sep2018/Project_Code/AgeOfEmpireGUI/src/resources/" +filename +".csv";
        FileWriter pw = new FileWriter(new File(path));

        StringBuilder sb = new StringBuilder();
        System.out.println(dataMap.size());

        String[] props = new String[]{"numberOfVillagersPlayerOne", "numberOfFightersPlayerOne", "numberOfHousesPlayerOne",
            "numberOfFightingUnitOne", "woodPlayerOne", "foodPlayerOne", "numberOfVillagersPlayerTwo", "numberOfFightersPlayerTwo", "numberOfHousesPlayerTwo",
            "numberOfFightingUnitTwo", "woodPlayerTwo", "foodPlayerTwo"};
        sb.append("Round");
        sb.append(',');
        sb.append("Winner");
        sb.append(',');
        sb.append(String.join(",", props));

        for (int x = 0; x < dataMap.size(); x++) {

            String num = String.valueOf(x + 1);
            if(dataMap.get(num) != null){
                HashMap<String, HashMap> roundDetails = dataMap.get(num);
                sb.append('\n');
                sb.append(roundDetails.get("winningDetails").get("Round"));
                sb.append(',');
                sb.append(roundDetails.get("winningDetails").get("Winner"));
                sb.append(',');

                for (int i = 0; i < props.length; i++) {
                    String key = props[i];
                    System.out.println();
                    sb.append(roundDetails.get("gameState").get(key));
                    sb.append(',');
                }
            } else {
                System.out.println("Ignore the round " + (x +1) + "Adding to CSV");
            }

        }

        pw.write(sb.toString());
        pw.close();
        System.out.println("done!");

    }
}
