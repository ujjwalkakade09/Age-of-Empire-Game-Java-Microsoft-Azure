/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empiresage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vinurip
 */
public class HumanPlayer extends Player{
    
 
 //   private Random r = new Random ();
    /**
      * Creates a new human player object by initialize the state of the player 
      * and the player identifier
      * @param state  first state of the player 
      * @param player identifier
    */
    public HumanPlayer(HashMap state, int PlayerNc) {
        super(state, PlayerNc);
        
    }
    
 
    /**
      * This method will return the current status since the player is Human
      * @param g current state
      * @return state
    */
    @Override
    public HashMap updateMove(HashMap g){
        return g;
     } 
    
      /**
      * This method will return updated current status as per the  the players 
      * selection
      * @param g current state
      * @param selectedStatus players selected status
      * @return state
    */
    @Override
    public HashMap updateMove(HashMap g,int selectedStatus){
        ageofempiresgui.EmpiresUI.comboActions.getSelectedItem();
        return this.getPossibleStatus(selectedStatus,g,playerN);
     }
    
}