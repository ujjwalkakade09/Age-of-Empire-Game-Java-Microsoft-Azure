/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empiresage;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.demo.charts.ExampleChart;
import org.knowm.xchart.style.Styler;


/**
 *
 * @author vinurip
 */
public class Charts implements ExampleChart<CategoryChart> {
    
    public static int x=0;
    
   String[] props = EmpiresConstants.props;
  @Override
  public CategoryChart getChart() {
    CategoryChart chart = new CategoryChartBuilder().width(800).height(600).title("Units vs Types").xAxisTitle("Types").yAxisTitle("Units").theme(Styler.ChartTheme.GGPlot2).build();
 
    chart.addSeries("Player1", new ArrayList<String>(Arrays.asList(EmpiresConstants.propsShort)),
            new ArrayList<Number>(Arrays.asList(new Number[] { EmpiresAge.getGameState().get(props[0] + "One"),
                EmpiresAge.getGameState().get(props[1] + "One"),
                EmpiresAge.getGameState().get(props[3] + "One") })));
    
    chart.addSeries("Player2", new ArrayList<String>(Arrays.asList(EmpiresConstants.propsShort)),
            new ArrayList<Number>(Arrays.asList(new Number[] { EmpiresAge.getGameState().get(props[0] + "Two"),
                EmpiresAge.getGameState().get(props[1] + "Two"),
                EmpiresAge.getGameState().get(props[3] + "Two") })));
  
   
    chart.getSeriesMap().get("Player1").setFillColor(EmpiresConstants.colorPlayer1);
    chart.getSeriesMap().get("Player2").setFillColor(EmpiresConstants.colorPlayer2);
    return chart;
  }
}
