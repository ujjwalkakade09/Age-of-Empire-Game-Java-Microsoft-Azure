package empiresage;

import java.util.HashMap;
import ageofempiresgui.*;
import java.util.ArrayList;
import javax.swing.SwingWorker;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.JDialog;

import javax.swing.JOptionPane;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.XChartPanel;
import org.knowm.xchart.demo.charts.ExampleChart;

/**
 *
 * @author Lydia
 */
public class EmpiresAge extends SwingWorker<List<HashMap>, HashMap> {

    /**
     * @param args the command line arguments just checking team stuff with this
     * comment another check
     */
    public  HashMap<String, Integer> gameState;
    public static HashMap<String, Integer> gameStateForCharts;
    public HashMap<String, Integer> winningDetails;
    public HashMap<String, HashMap> roundState;
    public static HashMap<String, HashMap> allRounds = new HashMap<String, HashMap>();
    public static int latestRound = 0;
    public int humanSelectedStatusID = 0;

    private EmpiresUI gg;
    String[] props;
    private final String MONTE_CARLO = "MonteCarlo";
    private final String MCTS = "MCTS";
    private final String MINMAX = "MinMax";
    private final String HUMAN = "Human";
    public Player player1;
    public Player player2;
    private XChartPanel pnlChart;
    private ExampleChart<CategoryChart> exampleChart;

    public EmpiresAge() {
        props = new String[]{"numberOfVillagersPlayer", "numberOfFightersPlayer", "numberOfHousesPlayer",
            "numberOfFightingUnit", "woodPlayer", "foodPlayer"};
        initialize();
    }

    public void setUI(EmpiresUI gg) {
        this.gg = gg;
    }
     
    public static  HashMap<String, Integer> getGameState(){
        return gameStateForCharts;
    }

    public void initialize() {
        gameState = new HashMap<String, Integer>();
        gameState.put("numberOfVillagersPlayerOne", 1);
        gameState.put("numberOfVillagersPlayerTwo", 1);
        gameState.put("numberOfFightersPlayerOne", 2);
        gameState.put("numberOfFightersPlayerTwo", 2);
        gameState.put("numberOfHousesPlayerOne", 1);
        gameState.put("numberOfHousesPlayerTwo", 1);
        gameState.put("numberOfFightingUnitOne", 1);
        gameState.put("numberOfFightingUnitTwo", 1);
        gameState.put("woodPlayerOne", 0);
        gameState.put("woodPlayerTwo", 0);
        gameState.put("foodPlayerOne", 0);
        gameState.put("foodPlayerTwo", 0);
        //details of the current round
        winningDetails = new HashMap<String, Integer>();
        winningDetails.put("Round", 0);
        winningDetails.put("Winner", 0);
        //summary of the current round
        roundState = new HashMap<String, HashMap>();
        roundState.put("gameState", gameState);
        roundState.put("winningDetails", winningDetails);

    }

    public static synchronized int getCount() {
        return latestRound++;
    }


    public void runGamePlayer(Player player1, Player player2) {

        boolean player1Announced = false;
        boolean player2Announced = false;
        while (!player2.endGame(gameState) && !player1.endGame(gameState)) {
            gameState = player1.updateMove(gameState);
            player2.setState(gameState);
            player1.setState(gameState);
            gameState = player2.updateMove(gameState);
            player2.setState(gameState);
            player1.setState(gameState);
            if (!player1Announced && player1.endGame(gameState)) {
                System.out.println("Player 1 won the game");
                player1Announced = true;
            }

            if (!player2Announced && player2.endGame(gameState)) {
                System.out.println("Player 2 won the game");
                player2Announced = true;
            }
            roundState.put("gameState", gameState);
            roundState.put("winningDetails", winningDetails);
            publish(roundState);
        }
        if (player1.endGame(gameState)) {
            System.out.println("Player 1 won the game " + Thread.currentThread().getId() + "   ");
            winningDetails.put("Winner", 1);
            allRounds.put(winningDetails.get("Round").toString(), roundState);

        }
        if (player2.endGame(gameState)) {
            System.out.println("Player 2 won the game " + winningDetails.get("Round").toString() + "   ");
            winningDetails.put("Winner", 2);
            allRounds.put(winningDetails.get("Round").toString(), roundState);
        }
    }

    public void setupGameForHumanVsAlgo(Player player1, Player player2) {

        gg.comboActions.removeAllItems();

        ArrayList<Integer> s = player1.possibleMoves(gameState, 1);
        for (int x = 0; x < s.size(); x++) {
            gg.comboActions.addItem(getStateName(s.get(x)));
        }
        gg.started = true;
        exampleChart = new Charts();
    }

    public void runGameHumanvsAlgo() throws InterruptedException {
        boolean player1Announced = false;
        boolean player2Announced = false;

        humanSelectedStatusID = getStateID(gg.comboActions.getSelectedItem().toString());

        if (!player2.endGame(gameState) && !player1.endGame(gameState)) {
            gameState = player1.updateMove(gameState, humanSelectedStatusID);
            player2.setState(gameState);
            player1.setState(gameState);
            JOptionPane panel = new JOptionPane("Please wait till player 2 makes a move", JOptionPane.INFORMATION_MESSAGE);

            JDialog dialog = panel.createDialog("Error");
            dialog.addWindowListener(null);
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            ScheduledExecutorService sch = Executors.newSingleThreadScheduledExecutor();
            sch.schedule(new Runnable() {
                public void run() {
                    dialog.setVisible(false);
                    dialog.dispose();
                }
            }, 2, TimeUnit.SECONDS);
            dialog.setVisible(true);

            gameState = player2.updateMove(gameState);
            player2.setState(gameState);
            player1.setState(gameState);

            if (!player1Announced && player1.endGame(gameState)) {
                System.out.println("Player 1 won the game");
                player1Announced = true;
            }

            if (!player2Announced && player2.endGame(gameState)) {
                System.out.println("Player 2 won the game");
                player2Announced = true;
            }
            roundState.put("gameState", gameState);
            roundState.put("winningDetails", winningDetails);
            gameStateForCharts = gameState;
            updateChart();
            
            publish(roundState);
        }
        setupGameForHumanVsAlgo(player1, player2);
        if (player1.endGame(gameState)) {
            System.out.println("Player 1 won the game " + Thread.currentThread().getId() + "   ");
            winningDetails.put("Winner", 1);
            allRounds.put(winningDetails.get("Round").toString(), roundState);
            JOptionPane.showMessageDialog(gg, "Player 1 won the game");
            gg.comboActions.setVisible(false);

        }
        if (player2.endGame(gameState)) {
            System.out.println("Player 2 won the game " + winningDetails.get("Round").toString() + "   ");
            winningDetails.put("Winner", 2);
            allRounds.put(winningDetails.get("Round").toString(), roundState);
            JOptionPane.showMessageDialog(gg, "Player 2 won the game");
            gg.comboActions.setVisible(false);
        }
        if (!player1.endGame(gameState) && !player2.endGame(gameState)) {
             JOptionPane.showMessageDialog(gg, "Please make your next move");
        }
    }

    private void updateChart() {
        CategoryChart chart = exampleChart.getChart();
        pnlChart = new XChartPanel(chart);
        gg.panalChart.removeAll();
        gg.panalChart.add(pnlChart);
        gg.panalChart.validate();
        //new SwingWrapper<CategoryChart>(chart).displayChart();
        //     EmpiresUI.panalChart.add(chart,BorderLayout .CENTER);
    }

    private Player getSelectedPlayer(String playerName, int playerId) {
        Player slectedPlayer;
        switch (playerName) {
            case MONTE_CARLO:
                slectedPlayer = new MonteCarlo(gameState, playerId);
                break;
            case MCTS:
                slectedPlayer = new MCTSPlayer(gameState, playerId);
                break;
            case MINMAX:
                slectedPlayer = new MinMaxPlayer(gameState, playerId);
                break;
            case HUMAN:
                slectedPlayer = new HumanPlayer(gameState, playerId);
                break;
            default:
                slectedPlayer = new MonteCarlo(gameState, playerId);
                break;

        }
        return slectedPlayer;
    }

    @Override
    protected List<HashMap> doInBackground() throws Exception {
        String player1SelectedItem = EmpiresUI.comboPlayer1.getSelectedItem().toString();
        String player2SelectedItem = EmpiresUI.comboPlayer2.getSelectedItem().toString();
        getCount();

        winningDetails.put("Round", latestRound);
        player1 = getSelectedPlayer(player1SelectedItem, 1);
        player2 = getSelectedPlayer(player2SelectedItem, 2);

        if (player1SelectedItem != HUMAN) {
            runGamePlayer(player1, player2);
        } else {
            setupGameForHumanVsAlgo(player1, player2);
        }

        return null;
    }

    @Override
    protected void process(List<HashMap> hms) {
        for (HashMap hm : hms) {
            gg.showState(hm);
        }
    }

    public String getStateName(int stateId) {
        switch (stateId) {
            case 1:
                return "Gather Wood";
            case 2:
                return "Gather Food";
            case 3:
                return "Build a house";
            case 4:
                return "Build a fighting unit";
            case 5:
                return "Get a villager";
            case 6:
                return "Get a fighter";
            default:
                return "No Action";
        }
    }

    public int getStateID(String stateName) {
        switch (stateName) {
            case "Gather Wood":
                return 1;
            case "Gather Food":
                return 2;
            case "Build a house":
                return 3;
            case "Build a fighting unit":
                return 4;
            case "Get a villager":
                return 5;
            case "Get a fighter":
                return 6;
            default:
                return 0;
        }
    }
}
