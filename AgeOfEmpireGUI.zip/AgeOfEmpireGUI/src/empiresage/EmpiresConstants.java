/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empiresage;

import java.awt.Color;

/**
 *
 * @author vinurip
 */
public class EmpiresConstants {
    
    public static Color  colorPlayer1 = new Color(137, 189, 211);
    public static Color  colorPlayer2 = new Color(224, 132, 133);
    
    public static String[] props = new String[]{"numberOfVillagersPlayer", "numberOfFightersPlayer", "numberOfHousesPlayer",
            "numberOfFightingUnit", "woodPlayer", "foodPlayer"};
     public static String[] propsShort = new String[]{"Villagers", "Fighters",
            "FightingUnit"};
     
    public static int villagerGoals = 5;
    public static int fightersGoals = 5;
    public static int fightingUnitsGoals = 2; 

}
